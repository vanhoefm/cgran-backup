#define UTS_RELEASE "2.6.24-19-generic"
